import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, ScrollView } from 'react-native';

const App = () => {
  const [nombre, setNombre] = useState('');
  const [salarioBase, setSalarioBase] = useState('');
  const [descuentoISSS, setDescuentoISSS] = useState(0);
  const [descuentoAFP, setDescuentoAFP] = useState(0);
  const [descuentoRENTA, setDescuentoRENTA] = useState(0);
  const [salarioNeto, setSalarioNeto] = useState(null);

  const calcularSalarioNeto = () => {
    if (nombre !== '' && salarioBase !== '') {
      const salarioBaseFloat = parseFloat(salarioBase);
      const ISSS = salarioBaseFloat * 0.03;
      const AFP = salarioBaseFloat * 0.04;
      const RENTA = salarioBaseFloat * 0.05;
      const salarioNetoCalculado = salarioBaseFloat - ISSS - AFP - RENTA;

      setDescuentoISSS(ISSS.toFixed(2));
      setDescuentoAFP(AFP.toFixed(2));
      setDescuentoRENTA(RENTA.toFixed(2));
      setSalarioNeto(salarioNetoCalculado.toFixed(2));
    } else {
      setSalarioNeto(null);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Calculadora de Salario Neto</Text>

      <View style={styles.inputContainer}>
        <Text style={styles.label}>Nombre del empleado:</Text>
        <TextInput
          style={styles.input}
          placeholder="Nombre"
          value={nombre}
          onChangeText={(text) => setNombre(text)}
        />

        <Text style={styles.label}>Salario Base:</Text>
        <TextInput
          style={styles.input}
          placeholder="Salario Base"
          value={salarioBase}
          onChangeText={(text) => setSalarioBase(text)}
          keyboardType="numeric"
        />

        <Button
          title="Calcular Salario Neto"
          onPress={calcularSalarioNeto}
          style={styles.button}
        />
      </View>

      {salarioNeto !== null && (
        <View style={styles.resultContainer}>
          <Text style={styles.result}>
            Descuento ISSS: ${descuentoISSS}
          </Text>
          <Text style={styles.result}>
            Descuento AFP: ${descuentoAFP}
          </Text>
          <Text style={styles.result}>
            Descuento RENTA: ${descuentoRENTA}
          </Text>
          <Text style={styles.result}>
            Salario neto de {nombre}: ${salarioNeto}
          </Text>
        </View>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f0f0',
    alignItems: 'center',
    paddingVertical: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  inputContainer: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
    elevation: 3,
  },
  label: {
    fontSize: 18,
    marginBottom: 8,
  },
  input: {
    width: '100%',
    height: 40,
    borderWidth: 1,
    borderColor: '#ccc',
    marginBottom: 16,
    paddingHorizontal: 8,
  },
  button: {
    marginBottom: 16,
  },
  resultContainer: {
    backgroundColor: '#fff',
    padding: 20,
    marginTop: 20,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
    elevation: 3,
  },
  result: {
    fontSize: 18,
    marginBottom: 8,
  },
});

export default App;

